<?php

// Profile
define('PROFIL_ADMIN', 'admin');
define('PROFIL_ETUDIANT', 'etudiant');

