<?php

// les informations de la base de données
define('DB_NAME', 'projet2');
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

// connexion vers la base de données
$connexion = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// arrêter si la connexion a échoue
if (!$connexion) {
    die("La connexion a échoué : " . mysqli_connect_error());
}
