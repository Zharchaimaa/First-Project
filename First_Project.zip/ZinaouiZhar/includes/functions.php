<?php


// constants de l'application
require 'constants.php';


// fonction qui permet la redirection selon le profile
function redirect($profil)
{
    global $message;
    switch ($profil) {
        case PROFIL_ETUDIANT:
            // redirection vers l'espace etudiant
            header('Location: etudiant/index.php');
            break;
        case PROFIL_ADMIN:
            // redirection vers l'espace administration
            header('Location: admin/index.php');
            break;
        default:
            // Profile n'existe pas
            $message = 'Échec de l\'ouverture de session';
    }
}
