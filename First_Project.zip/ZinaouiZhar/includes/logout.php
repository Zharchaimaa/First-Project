<?php
// se déconnecter
if (isset($_GET['logout'])) {

    // suppriner la session
    session_unset();
    session_destroy();

    // redirection vers la page login
    header('location: http://localhost/ZinaouiZhar');
}


