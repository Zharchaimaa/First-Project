<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

// message d'erreur
$message = '';

// fonctions
require 'includes/functions.php';

//Redirection si déjà connecté
if (isset($_SESSION['username'])) {
    redirect($_SESSION['profil']);
    exit();
}

// authentication
if (isset($_POST['login']) && isset($_POST['username']) && !empty($_POST['username']) && isset($_POST['password']) && !empty($_POST['password'])) {

    // connexion à la base de données
    require 'includes/connect.php';

    // on applique les deux fonctions mysqli_real_escape_string et htmlspecialchars
    // pour éliminer toute attaque de type injection SQL et XSS
    $username = mysqli_real_escape_string($connexion, htmlspecialchars($_POST['username']));
    $passwod = mysqli_real_escape_string($connexion, htmlspecialchars($_POST['password']));

    // récupérer les informations d'utilisateur de puis BD
    $requete = "SELECT USERNAME AS USERNAME, PASSWORD AS PASSWORD, PROFIL AS PROFIL, CNE AS CNE FROM UTILISATEUR where USERNAME = '$username' ";
    $exec_requete = mysqli_query($connexion, $requete);
    $reponse = mysqli_fetch_assoc($exec_requete);

    // nom d'utilisateur et mot de passe correctes
    if ($reponse['USERNAME'] == $username && $reponse['PASSWORD'] == sha1($passwod)) {

        // crée une session
        $_SESSION['username'] = $reponse['USERNAME'];
        $_SESSION['profil'] = $reponse['PROFIL'];
        $_SESSION['cne'] = $reponse['CNE'];

        // redirection selon le profile
        redirect($reponse['PROFIL']);

    } else {
        $message = 'Le code massar ou mot de passe est incorrect';
    }

    // fermer la connexion
    mysqli_close($connexion);
}

?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/loginStyle.css">
    <title> Login | ENSA Khouribga – Université Sultan Moulay Slimane</title>
</head>

<body>

<!-- begin::content -->
<div class="login-reg-panel">

    <!-- begin::Login -->
    <div class="login-info-box">
        <h2>Avez vous un compte ?</h2>
        <label id="label-register" for="log-reg-show">Se connecter</label>
        <input type="radio" name="active-log-panel" id="log-reg-show" checked="checked">
    </div>
    <!-- end::Login -->

    <!-- begin::Register -->
    <div class="register-info-box">
        <h2>Vous n'avez pas de compte ?</h2>
        <label id="label-login" for="log-login-show">S'inscrire</label>
        <input type="radio" name="active-log-panel" id="log-login-show">
    </div>
    <!-- end::Register -->

    <div class="white-panel">
        <!-- begin::Form-Login -->
        <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
            <div class="login-show">
                <h2>SE CONNECTER</h2>
                <?php if (!empty($message)): ?>
                    <div class="alert alert-danger" role="alert">
                        <?= $message ?>
                    </div>
                <?php endif ?>
                <input type="text" name="username" placeholder="Code Massar">
                <input type="password" name="password" placeholder="mot de passe">
                <img src="assets/image/logoENSA.png" height="40px" width="65px">
                <input type="submit" name="login" value="Se connecter">
            </div>
        </form>
        <!-- end::Form-Login -->

        <!-- begin::Form-Register -->
        <div class="register-show">
            <h2>S'INSCRIRE</h2>
            <input type="text" placeholder="Code Massar">
            <input type="password" placeholder="mot de passe">
            <input type="password" placeholder="Confirmer mot de passe">
            <input type="submit" value="S'inscrire">
        </div>
        <!-- end::Form-Register -->
    </div>

</div>
<!-- end::content -->

<!-- begin::JS -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/loginJS.js"></script>
<!-- end::JS -->

</body>
</html>