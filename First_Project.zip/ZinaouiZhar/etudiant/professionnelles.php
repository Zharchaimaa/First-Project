<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// message d'infos
$message = '';

if (isset($_POST['envoyer'])) {

    // connexion à la base de données
    require '../includes/connect.php';

    // récupérer CNE depuis la session
    $cne = $_SESSION['cne'];

    // récupérer les infos de formulaire
    $q1 = $_POST['q1'];
    $place = $_POST['place'];
    $secteur = $_POST['secteur'];
    $organisme = $_POST['organisme'];
    $temps = $_POST['temps'];
    $moyenEmploi = $_POST['moyenEmploi'];
    $q2 = $_POST['q2'];
    $placeDoc = $_POST['placeDoc'];

    // insérer les données
    $insert = "INSERT INTO INFORMATION_PROFESSIONNELLE (CNE,TRAVAIL,VILLE_PAYS,SECTEUR,ORGANISME,TEMPS_POUR_TRAVAIL,MOYEN_TRAVAIL,INSCRIRE_DOC,VILLE_PAYS_DOC) VALUES ('$cne','$q1','$place','$secteur','$organisme','$temps','$moyenEmploi','$q2','$placeDoc')";
    $result = mysqli_query($connexion, $insert);

    // message d'information
    if ($result) {
        $message = 'votre reclamation est envoyé !';
    } else {
        $message = "votre reclamation n'est pas envoyé!";
    }

    // fermer la connexion
    mysqli_close($connexion);
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acceuil | Espace etudiant</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/styeInser.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
</head>

<body>

<?php if ($_SESSION['profil'] == PROFIL_ETUDIANT): ?>

    <!-- begin::Infos-profesionnelles -->
    <div class="container">
        <form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
            <?php if (!empty($message)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $message ?>
                </div>
            <?php endif ?>
            <fieldset>
                <legend class="title"><strong>Insertion professionnelle </strong></legend>
                <p class="para1">

                    <strong>Avez-vous décroché un travail ?</strong>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" value="oui">
                    <label class="form-check-label">
                        Oui
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q1" value="non">
                    <label class="form-check-label">
                        Non
                    </label>
                </div>
                </p>

                <div class="mb-3">
                    <label class="form-label"><strong>Si Oui veuillez préciser la ville si c'est au Maroc sinon
                            préciser
                            le pays</strong></label>
                    <input type="text" class="form-control" name="place" size="30">
                </div>

                <div class="mb-3">
                    <label class="form-label"><strong> Dans quel secteur d'activité économique ?</strong></label>
                    <input type="text" class="form-control" name="secteur" size="30">
                </div>

                <div class="mb-3">
                    <label for="organisme" class="form-label"><strong> Préciser l'organisme employeur
                            ?</strong></label>
                    <input type="text" class="form-control" name="organisme" size="30">
                </div>

                <div class="mb-3">
                    <label class="form-label"><strong> Combien de temps avez-vous mis pour décrocher un premier
                            emploi
                            ?</strong></label>
                    <input type="text" class="form-control" name="temps" size="30">
                </div>

                <div class="mb-3">
                    <label class="form-label"><strong> Par quel moyen avez-vous trouvé votre emploi
                            ?</strong></label>
                    <input type="text" class="form-control" name="moyenEmploi" size="30">
                </div>

                <p>
                <p><label class="form-label"><strong>Etes-vous inscri(e) en doctorat ?</strong></label> :</p>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q2" value="oui">
                    <label class="form-check-label">
                        Oui
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="q2" value="non">
                    <label class="form-check-label">
                        Non
                    </label>
                </div>
                </p>

                <div class="mb-3">
                    <label class="form-label"><strong>Si Oui veuillez préciser l'université si c'est au Maroc sinon
                            préciser le pays</strong></label>
                    <input type="text" class="form-control" name="placeDoc" size="30">
                </div>

                <p>
                <center>

                    <button type="submit" class="btn btn-success btn-sm" name="envoyer">Envoyer</button>
                    <button type="button" class="btn btn-danger btn-sm">Annuler</button>
                </center>
                </p>
            </fieldset>
        </form>
    </div>
    <!-- end::Infos-profesionnelles -->

    <!-- begin::Menu -->
    <div id="divnav">
        <nav>
            <ul>
                <li><a href="index.php">Acceuil</a></li>
                <li><a href="verification.php">Verifié les Données</a></li>
                <li><a href="reclamation.php">Reclamation</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>">Isertion Données</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
            </ul>
        </nav>
    </div>
    <div id="menubtn">
        <img src="../assets/image/menub.png" id="menu">
    </div>
    <!-- end::Menu -->

    <script>
        var menubtn = document.getElementById("menubtn")
        var divnav = document.getElementById("divnav")
        var menu = document.getElementById("menu")

        menubtn.onclick = function () {
            if (divnav.style.right == "-250px") {
                divnav.style.right = "0";
                menu.src = "../assets/image/closeb.png"
            } else {
                divnav.style.right = "-250px";
                menu.src = "../assets/image/menub.png"
            }
        }
    </script>

<?php else: ?>
    <div style="text-align: center">
        <h3>Vous n'avez pas la permission de voir ce contenu.</h3>
    </div>
<?php endif; ?>
</body>
</html>

