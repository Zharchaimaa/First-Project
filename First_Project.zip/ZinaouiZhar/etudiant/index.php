<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Acceuil | Espace etudiant</title>
    <link rel="stylesheet" type="text/css" href="../assets/css/acceuilStyle.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
</head>

<body>


<?php if ($_SESSION['profil'] == PROFIL_ETUDIANT): ?>

    <!-- begin::Etudiant -->
    <section id="arriere">
        <div class="felicitation">
            <span class="fel">Félicitation</span><br/>
            Un diplôme est une entrée dans un monde nouveau plein de promesses<br/> et nous sommes tellement fier que
            vous soyez prêt à prendre<br/>votre place dans ce nouveau monde.<br/> Bravo pour tout le chemin<br/>
            accompli !<br/>
            <div class="btn">
                <a href="verification.php"><span></span> verifier<br/> vos Données</a>
                <a href="professionnelles.php"><span></span> Informations Professionelles</a>
            </div>
        </div>
    </section>
    <!-- end::Etudiant -->

    <!-- begin::Menu-->
    <div id="divnav">
        <nav>
            <ul>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>">Acceuil</a></li>
                <li><a href="verification.php">Verifié les Données</a></li>
                <li><a href="reclamation.php">Reclamation</a></li>
                <li><a href="professionnelles.php">Isertion Données</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
            </ul>
        </nav>
    </div>
    <div id="menubtn">
        <img src="../assets/image/menub.png" id="menu">
    </div>
    <!-- end::Menu-->

    <script>
        var menubtn = document.getElementById("menubtn")
        var divnav = document.getElementById("divnav")
        var menu = document.getElementById("menu")

        menubtn.onclick = function () {
            if (divnav.style.right == "-250px") {
                divnav.style.right = "0";
                menu.src = "../assets/image/closeb.png"
            } else {
                divnav.style.right = "-250px";
                menu.src = "../assets/image/menub.png"
            }
        }
    </script>

<?php else: ?>
    <div style="text-align: center">
        <h3>Vous n'avez pas la permission de voir ce contenu.</h3>
    </div>
<?php endif; ?>


</body>
</html>

