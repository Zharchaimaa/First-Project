<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// connexion à la base de données
require '../includes/connect.php';

// message d'infos
$message = '';

// récupérer CNE depuis la session
$cne = $_SESSION["cne"];


if (isset($_GET['valider'])) {

    // confirmer les infos d'etudiant
    $update = "UPDATE ETUDIANT SET CONFIRMATION = 1 where CNE = '$cne'";
    $result = mysqli_query($connexion, $update);

    // message d'information
    if ($result) {
        $message = 'votre confirmation est envoyé !';
    } else {
        $message = "votre confirmation n'est pas envoyé!";
    }
}

$select = "SELECT CNE AS CNE, NOM AS NOM, NOM_AR AS NOM_AR, PRENOM AS PRENOM, PRENOM_AR AS PRENOM_AR, DATE_NAISSANCE AS DATE_NAISSANCE, LIEU_NAISSANCE AS LIEU_NAISSANCE, LIEU_NAISSANCE_AR AS LIEU_NAISSANCE_AR, DATE_OBTENTION AS DATE_OBTENTION, FILIERE AS FILIERE, FILIERE_AR AS FILIERE_AR, SEXE AS SEXE, CONFIRMATION AS CONFIRMATION FROM ETUDIANT where CNE = '$cne'";
$results = mysqli_query($connexion, $select);
$data = mysqli_fetch_assoc($results);

// fermer la connexion
mysqli_close($connexion);

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/verification.css">
    <title>Verification de Donnees | Espace Etudiant</title>
</head>
<body>
<?php if ($_SESSION['profil'] == PROFIL_ETUDIANT): ?>
    <div class="container">
        <div class="title">Vérification de Données</div>
        <?php if (!empty($message)): ?>
            <div class="alert alert-success" role="alert">
                <?= $message ?>
            </div>
        <?php endif ?>
        <form action="<?= $_SERVER['PHP_SELF'] ?>" METHOD="post">
            <div class="user-details" id="form_fr">
                <div class="input-box">
                    <span class="details">Nom Complet</span>
                    <input type="text" placeholder="Entrer votre nom"
                           value="<?= $data['NOM'] . ' ' . $data['PRENOM'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">CIN</span>
                    <input type="text" name="CINE" value="<?= $data['CNE'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">Date de Naissance</span>
                    <input type="date" name="DATE_NAISSANCE" value="<?= $data['DATE_NAISSANCE'] ?>" readonly
                           pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                </div>
                <div class="input-box">
                    <span class="details">Lieu de naissance</span>
                    <input type="text" name="LIEU_NAISSANCE" value="<?= $data['LIEU_NAISSANCE'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">Filière</span>
                    <input type="text" name="FILIERE" value="<?= $data['FILIERE'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">Date d'obtention</span>
                    <input type="text" value="<?= $data['DATE_OBTENTION'] ?>" name="DATE_OBTENTION" readonly>
                </div>
                <div class="input-box">
                    <span class="details">Genre</span>
                    <input type="text" value="<?= $data['SEXE'] ?>" name="SEXE" readonly>
                </div>
                <div class="btn">
                    <a onclick="form_arab()"> suivant ➜</a>
                </div>
            </div>

            <div class="user-details" style="display: none" id="form_ar">
                <div class="input-box">
                    <span class="details">الاسم الكامل  </span>
                    <input type="text" placeholder="Entrer votre nom"
                           value="<?= $data['NOM_AR'] . ' ' . $data['PRENOM_AR'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">رقم البطاقة الوطنية  </span>
                    <input type="text" name="CINE" value="<?= $data['CNE'] ?>" readonly>
                </div>
                <div class="input-box">
                    <span class="details">تاريخ الإزدياد  </span>
                    <input type="date" name="DATE_NAISSANCE" value="<?= $data['DATE_NAISSANCE'] ?>" readonly
                           pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
                </div>
                <div class="input-box">
                    <span class="details">مكان الإزدياد </span>
                    <input type="text" name="LIEU_NAISSANCE_AR" value="<?= $data['LIEU_NAISSANCE_AR'] ?>"
                           readonly>
                </div>
                <div class="input-box">
                    <span class="details">تاريخ التحرير </span>
                    <input type="text" value="<?= $data['DATE_OBTENTION'] ?>" name="DATE_OBTENTION"
                           readonly>
                </div>
                <div class="input-box">
                    <span class="details">شعبة  </span>
                    <input type="text" name="FILIERE_AR" value="<?= $data['FILIERE_AR'] ?>" readonly>
                </div>

                <?php if ($data['CONFIRMATION'] == 0): ?>
                    <div class="btn">
                        <a href="<?= $_SERVER['PHP_SELF'] ?>?valider"> Valider</a>
                    </div>
                <?php endif ?>
            </div>
        </form>
    </div>
    </section>
    <div id="divnav">
        <nav>
            <ul>
                <li><a href="index.php">Acceuil</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>">Verifié les Données</a></li>
                <li><a href="reclamation.php">Reclamation</a></li>
                <li><a href="professionnelles.php">Isertion Données</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
            </ul>
        </nav>
    </div>
    <div id="menubtn">
        <img src="../assets/image/menub.png" id="menu">
    </div>

    <script>
        var menubtn = document.getElementById("menubtn")
        var divnav = document.getElementById("divnav")
        var menu = document.getElementById("menu")

        menubtn.onclick = function () {
            if (divnav.style.right == "-250px") {
                divnav.style.right = "0";
                menu.src = "../assets/image/closeb.png"
            } else {
                divnav.style.right = "-250px";
                menu.src = "../assets/image/menub.png"
            }
        }

        function form_arab() {
            document.getElementById("form_fr").style.display = "none";
            document.getElementById("form_ar").style.display = "";
        }

    </script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">

        /*swal("verifiez vos données", "avant de telecharger votre diplome il faut verifier votre coordonnées ");*/
        swal("verification des données", "veuillez verifier vos données  ", "info");
    </script>
<?php endif; ?>
</body>
</html>