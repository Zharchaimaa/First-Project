<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// message d'infos
$message = '';

if (isset($_POST['envoyer']) && isset($_POST['reclamation']) && !empty($_POST['reclamation']) && isset($_POST['email']) && !empty($_POST['email'])) {

    // connexion à la base de données
    require '../includes/connect.php';

    // récupérer CNE depuis la session
    $cne = $_SESSION["cne"];

    // récupérer les infos de formulaire
    $reclamation = $_POST['reclamation'];
    $email = $_POST['email'];

    // ajouter la réclamation
    $insert = "INSERT INTO RECLAMATION (CNE,RECLAMATION,EMAIL) VALUES ('$cne','$reclamation','$email')";
    $result = mysqli_query($connexion, $insert);

    if ($result) {
        $message = 'votre reclamation est envoyé !';
    } else {
        $message = "votre reclamation n'est pas envoyé!";
    }
}


?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title> Reclamation | Espace Etudiant </title>
    <!--<!-Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <link rel="stylesheet" type="text/css" href="../assets/css/reclamationStyle.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php if ($_SESSION['profil'] == PROFIL_ETUDIANT): ?>
    <div class="container">
        <div class="content">
            <div class="left-side">
                <div class="address details">
                    <i class="fas fa-map-marker-alt"></i>
                    <div class="topic">Adresse</div>
                    <div class="text-one">Bd Béni Amir BP 77</div>
                    <div class="text-two">Khouribga - Maroc</div>
                </div>
                <div class="phone details">
                    <i class="fas fa-phone-alt"></i>
                    <div class="topic">contact</div>
                    <div class="text-one">+212523492335</div>
                    <div class="text-two">+212618534372</div>
                </div>
                <div class="email details">
                    <i class="fas fa-envelope"></i>
                    <div class="topic">Email</div>
                    <div class="text-one">contact.ensak@usms.ma</div>
                </div>
            </div>
            <div class="right-side">
                <div class="topic-text">Réclamation</div>
                <p> Veuillez saisir les champs qui semblent incorrect</p>
                <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
                    <?php if (!empty($message)): ?>
                        <div class="alert alert-success" role="alert">
                            <?= $message ?>
                        </div>
                    <?php endif ?>
                    <div class="input-box">
                        <textarea type="text" placeholder="Champs" name="reclamation"></textarea>
                    </div>
                    <div class="input-box">
                        <input type="text" placeholder="Entrer votre Email" name="email">
                    </div>
                    <div class="input-box message-box">

                    </div>
                    <div class="button">
                        <input type="submit" id="alert" value="Envoyer" name="envoyer">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="divnav">
        <nav>
            <ul>
                <li><a href="index.php">Acceuil</a></li>
                <li><a href="verification.php">Verifié les Données</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>">Reclamation</a></li>
                <li><a href="professionnelles.php">Isertion Données</a></li>
                <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
            </ul>
        </nav>
    </div>
    <div id="menubtn">
        <img src="../assets/image/menub.png" id="menu">
    </div>

    <script>
        var menubtn = document.getElementById("menubtn")
        var divnav = document.getElementById("divnav")
        var menu = document.getElementById("menu")

        menubtn.onclick = function () {
            if (divnav.style.right == "-250px") {
                divnav.style.right = "0";
                menu.src = "../assets/image/closeb.png"
            } else {
                divnav.style.right = "-250px";
                menu.src = "../assets/image/menub.png"
            }
        }
    </script>
<?php endif; ?>
</body>
</html>
