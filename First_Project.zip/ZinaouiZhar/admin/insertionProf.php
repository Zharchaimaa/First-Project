<?php

// désactiver l'affichage des erreurs
error_reporting(0);


session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// connexion à la base de données
require '../includes/connect.php';

// message d'infos
$message = '';

$select = "SELECT * FROM INFORMATION_PROFESSIONNELLE";
$results = mysqli_query($connexion, $select);
$data = mysqli_fetch_all($results, MYSQLI_ASSOC);

// fermer la connexion
mysqli_close($connexion);
?>
<!DOCTYPE html>
<html>
<head>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="../assets/css/styleNav.css">
    </head>
</head>
<body>
<?php if ($_SESSION['profil'] == PROFIL_ADMIN): ?>


<header>
    <img src="../assets/image/logoENSA.png" alt="logo" class="logo">
    <nav>
        <ul class="nav_links">
            <li><a href="index.php">acceuil</a></li>
            <li><a href="ajouter_etudiant.php">Ajouter_Etudiant</a></li>
            <li><a href="ajouter_utilisateur.php">Ajouter_utilisateur</a></li>
            <li><a href="reclamation.php">Réclamation</a></li>
            <li><a href="insertionProf.php">Insertion professionelle</a></li>
        </ul>
    </nav>
    <a href="<?= $_SERVER['PHP_SELF'] ?>?logout" class="cta">
        <button class="bt">Déconnexion</button>
    </a>
</header>

<div class="container">
    <p style="margin-top: 50px;">Les données professionnelles des etudiants </p>
    <table class="table">
        <thead>
        <tr class="info">
            <th>CNE</th>
            <th>Trouve_trv</th>
            <th>Ville_Pays</th>
            <th>Secteur</th>
            <th>Organisme</th>
            <th>Durée de chommage</th>
            <th>Moyen</th>
            <th>Inscrire Doc</th>
            <th>ville ou pays de Doc</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($data as $row): ?>
            <tr>
                <td> <?= $row['CNE'] ?> </td>
                <td> <?= $row['TRAVAIL'] ?> </td>
                <td> <?= $row['VILLE_PAYS'] ?> </td>
                <td> <?= $row['SECTEUR'] ?> </td>
                <td> <?= $row['ORGANISME'] ?> </td>
                <td> <?= $row['TEMPS_POUR_TRAVAIL'] ?> </td>
                <td> <?= $row['MOYEN_TRAVAIL'] ?> </td>
                <td> <?= $row['INSCRIRE_DOC'] ?> </td>
                <td> <?= $row['VILLE_PAYS_DOC'] ?> </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
<?php endif; ?>
</html>