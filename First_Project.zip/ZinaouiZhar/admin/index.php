<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// connexion à la base de données
require '../includes/connect.php';

// message d'infos
$message = '';

if (isset($_GET['supprimer']) && !empty($_GET['supprimer'])) {

    // récupérer le CNE
    $cne = $_GET['supprimer'];

    // supprimer d'etudiant
    $delete = "DELETE FROM ETUDIANT WHERE CNE = '$cne'";
    $result = mysqli_query($connexion, $delete);
    if ($result) {
        $message = 'L\'etudiant supprimé avec succès';
    } else {
        $message = 'Une erreur a été détecte pendant l\'execution de votre requête';
    }
}


// récupérer la liste des etudiants
$select = "SELECT * FROM ETUDIANT";
$results = mysqli_query($connexion, $select);
$data = mysqli_fetch_all($results, MYSQLI_ASSOC);

// fermer la connexion
mysqli_close($connexion);
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../assets/css/styleNav.css">
</head>
<body>

<?php if ($_SESSION['profil'] == PROFIL_ADMIN): ?>

    <header>
        <img src="../assets/image/logoENSA.png" alt="logo" class="logo">
        <nav>
            <ul class="nav_links">
                <li><a href="index.php">acceuil</a></li>
                <li><a href="ajouter_etudiant.php">Ajouter_Etudiant</a></li>
                <li><a href="ajouter_utilisateur.php">Ajouter_utilisateur</a></li>
                <li><a href="reclamation.php">Réclamation</a></li>
                <li><a href="insertionProf.php">Insertion professionelle</a></li>

            </ul>
        </nav>
        <a href="<?= $_SERVER['PHP_SELF'] ?>?logout" class="cta">
            <button class="bt">Déconnexion</button>
        </a>
    </header>

    <div class="container">
        <h4 style=" margin-top: 30px;">Table des etudiants</h4>

        <?php if (!empty($message)): ?>
            <div class="alert alert-success" role="alert">
                <?= $message ?>
            </div>
        <?php endif ?>

        <table class="table">
            <thead>
            <tr class="info">
                <th>CNE</th>
                <th>NOM</th>
                <th>PRENOM</th>
                <th>FILIERE</th>
                <th>DATE NAISSANCE</th>
                <th>CONFIRMATION</th>
                <th>
                    <center>ACTION</center>
                </th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                    <th scope="row"> <?= $row['CNE'] ?> </th>
                    <td> <?= $row['NOM'] ?> </td>
                    <td> <?= $row['PRENOM'] ?> </td>
                    <td> <?= $row['FILIERE'] ?> </td>
                    <td> <?= $row['DATE_NAISSANCE'] ?></td>
                    <td> <?= $row['CONFIRMATION'] == 0 ? 'Non' : 'Oui' ?> </td>
                    <td>
                        <button type="button" class="btn btn-succes"><a
                                    href="modifier_etudiant.php?cne=<?= $row['CNE'] ?>"
                                    class="btn">Modifier</a></button>
                    </td>
                    <td>
                        <button type="button" class="btn btn-succes"><a
                                    href="<?= $_SERVER['PHP_SELF'] ?>?supprimer=<?= $row['CNE'] ?>"
                                    class="btn">Supprimer</a></button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

<?php endif; ?>
</body>
</html>