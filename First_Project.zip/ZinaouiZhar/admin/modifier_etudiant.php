<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// connexion à la base de données
require '../includes/connect.php';

// message d'infos
$message = '';

if (isset($_GET['cne']) && !empty($_GET['cne'])) {

    // récupérer le CNE
    $cne = $_GET['cne'];

    // récupérer les infos d'etudiant
    $select = "SELECT * FROM ETUDIANT where CNE='$cne'";
    $results = mysqli_query($connexion, $select);
    $data = mysqli_fetch_assoc($results);
}


if (isset($_POST['modifier'])) {

    // récupérer formulaire
    $cne = $_POST['CNE'];
    $nom = $_POST['NOM'];
    $nom_ar = $_POST['NOM_AR'];
    $prenom = $_POST['PRENOM'];
    $prenom_ar = $_POST['PRENOM_AR'];
    $cine = $_POST['CINE'];
    $date_naissance = $_POST['DATE_NAISSANCE'];
    $lieu_naissance = $_POST['LIEU_NAISSANCE'];
    $lieu_naissance_ar = $_POST['LIEU_NAISSANCE_AR'];
    $date_obtention = $_POST['DATE_OBTENTION'];
    $filiere = $_POST['FILIERE'];
    $filiere_ar = $_POST['FILIERE_AR'];
    $sexe = $_POST['SEXE'];
    $confirmation = $_POST['CONFIRMATION'];


    // modifier l'etudiant
    $update = "UPDATE  ETUDIANT SET CNE = '$cne', NOM='$nom', NOM_AR='$nom_ar',PRENOM='$prenom',PRENOM_AR='$prenom_ar',CNE='$cne',DATE_NAISSANCE='$date_naissance',LIEU_NAISSANCE='$lieu_naissance',LIEU_NAISSANCE_AR='$lieu_naissance_ar',DATE_OBTENTION='$date_obtention',FILIERE='$filiere',FILIERE_AR='$filiere_ar',SEXE='$sexe',CONFIRMATION='$confirmation' where CNE = '$cne'";
    $resultat = mysqli_query($connexion, $update);

    if ($resultat) {
        header("location: index.php");
    } else {
        $message = 'Une erreur a été détecte pendant l\'execution de votre requête';
    }
}

// fermer la connexion
mysqli_close($connexion);
?>

<!DOCTYPE html>
<html>
<head>
    <!--<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../assets/css/ajoutUtilisateur.css">

</head>
<body>
<div class="container">
    <div class="title">Modifier les informations d'un etudiant</div>

    <?php if (!empty($message)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $message ?>
        </div>
    <?php endif ?>

    <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
        <div class="user-details">
            <div class="input-box">
                <span class="details">CNE</span>
                <input type="text" required name="CNE" value="<?= $data['CNE'] ?>">
            </div>
            <div class="input-box">
                <span class="details">Non</span>
                <input type="text" name="NOM" value="<?= $data['NOM'] ?>" required>
            </div>
            <div class="input-box">
                <span class="details">Non en arabe</span>
                <input type="text" name="NOM_AR" value="<?= $data['NOM_AR'] ?>" required>
            </div>
            <div class="input-box">
                <span class="details">Prenom</span>
                <input type="text" name="PRENOM" value="<?= $data['PRENOM'] ?>" required>
            </div>
            <div class="input-box">
                <span class="details">Prenom en arabe</span>
                <input type="text" name="PRENOM_AR" value="<?= $data['PRENOM_AR'] ?>" required>
            </div>
            <div class="input-box">
                <span class="details">CINE</span>
                <input type="hiden" name="CINE" value="<?= $data['CNE'] ?>" required>
            </div>
            <div class="input-box">
                <span class="details">Date de Naissance</span>
                <input type="date" value="<?= $data['DATE_NAISSANCE'] ?>" required
                       pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" name="DATE_NAISSANCE">
            </div>
            <div class="input-box">
                <span class="details">Lieu de naissance</span>
                <input type="text" value="<?= $data['LIEU_NAISSANCE'] ?>" name="LIEU_NAISSANCE" required>
            </div>
            <div class="input-box">
                <span class="details">Lieu de naissance en arabe</span>
                <input type="text" value="<?= $data['LIEU_NAISSANCE_AR'] ?>" name="LIEU_NAISSANCE_AR" required>
            </div>
            <div class="input-box">
                <span class="details">Date de l'obtention de diplome</span>
                <input type="text" value="<?= $data['DATE_OBTENTION'] ?>"
                       pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" name="DATE_OBTENTION" required>
            </div>
            <div class="input-box">
                <span class="details">filiere</span>
                <input type="text" value="<?= $data['FILIERE'] ?>" required name="FILIERE">
            </div>
            <div class="input-box">
                <span class="details">filiere en arabe</span>
                <input type="text" value="<?= $data['FILIERE_AR'] ?>" required name="FILIERE_AR">
            </div>
            <div class="input-box">
                <span class="details">l'etat de confirmation de données</span>
                <input type="text" value="<?= $data['CONFIRMATION'] ?>" required name="CONFIRMATION">
            </div>
            <div class="input-box">
                <span class="details">sexe</span>
                <input type="text" value="<?= $data['SEXE'] ?>" required name="SEXE">
            </div>


            <button type="submit" name="modifier" class="btn">Modifier</button>
        </div>
    </form>
</div>

<div id="divnav">
    <nav>
        <ul>
            <li><a href="index.php">acceuil</a></li>
            <li><a href="ajouter_etudiant.php">Ajouter_Etudiant</a></li>
            <li><a href="ajouter_utilisateur.php">Ajouter_utilisateur</a></li>
            <li><a href="reclamation.php">Réclamation</a></li>
            <li><a href="insertionProf.php">Insertion professionelle</a></li>
            <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
        </ul>
    </nav>
</div>
<div id="menubtn">
    <img src="../assets/image/menub.png" id="menu">
</div>

<script>
    var menubtn = document.getElementById("menubtn")
    var divnav = document.getElementById("divnav")
    var menu = document.getElementById("menu")

    menubtn.onclick = function () {
        if (divnav.style.right == "-250px") {
            divnav.style.right = "0";
            menu.src = "../assets/image/closeb.png"
        } else {
            divnav.style.right = "-250px";
            menu.src = "../assets/image/menub.png"
        }
    }
</script>


</body>
</html>
