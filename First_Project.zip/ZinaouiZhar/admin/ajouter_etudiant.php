<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// message d'infos
$message = '';

if (isset($_POST['enregistrer'])) {

    // connexion à la base de données
    require '../includes/connect.php';

    // récupérer formulaire
    $cne = $_POST['CNE'];
    $nom = $_POST['NOM'];
    $nom_ar = $_POST['NOM_AR'];
    $prenom = $_POST['PRENOM'];
    $prenom_ar = $_POST['PRENOM_AR'];
    $date_naissance = $_POST['DATE_NAISSANCE'];
    $lieu_naissance = $_POST['LIEU_NAISSANCE'];
    $lieu_naissance_ar = $_POST['LIEU_NAISSANCE_AR'];
    $date_obtention = $_POST['DATE_OBTENTION'];
    $filiere = $_POST['FILIERE'];
    $filiere_ar = $_POST['FILIERE_AR'];
    $sexe = $_POST['SEXE'];

    // ajouter etudiant
    $insert = "INSERT INTO ETUDIANT (CNE,NOM,NOM_AR,PRENOM,PRENOM_AR,DATE_NAISSANCE,LIEU_NAISSANCE,LIEU_NAISSANCE_AR,DATE_OBTENTION,FILIERE,FILIERE_AR,SEXE,CONFIRMATION) VALUES 
                ('$cne','$nom','$nom_ar','$prenom','$prenom_ar','$date_naissance','$lieu_naissance','$lieu_naissance_ar','$date_obtention','$filiere','$filiere_ar','$sexe', 0)";
    $result = mysqli_query($connexion, $insert);

    if ($result) {
        header('location: index.php');
    } else {
        die(mysqli_error($connexion));
        $message = 'Une erreur a été détecte pendant l\'execution de votre requête';
    }

    // fermer la connexion
    mysqli_close($connexion);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/ajoutUtilisateur.css">
</head>
<body>
<div class="container">
    <div class="title">Ajouter un etudiant</div>
    <?php if (!empty($message)): ?>
        <div class="alert alert-danger" role="alert">
            <?= $message ?>
        </div>
    <?php endif ?>
    <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
        <div class="user-details">
            <div class="input-box">
                <span class="details">CNE</span>
                <input type="text" required name="CNE">
            </div>
            <div class="input-box">
                <span class="details">Non</span>
                <input type="text" name="NOM" required>
            </div>
            <div class="input-box">
                <span class="details">Non en arabe</span>
                <input type="text" name="NOM_AR" required>
            </div>
            <div class="input-box">
                <span class="details">Prenom</span>
                <input type="text" name="PRENOM" required>
            </div>
            <div class="input-box">
                <span class="details">Prenom en arabe</span>
                <input type="text" name="PRENOM_AR" required>
            </div>
            <div class="input-box">
                <span class="details">Date de Naissance</span>
                <input type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" name="DATE_NAISSANCE">
            </div>
            <div class="input-box">
                <span class="details">Lieu de naissance</span>
                <input type="text" name="LIEU_NAISSANCE" required>
            </div>
            <div class="input-box">
                <span class="details">Lieu de naissance en arabe</span>
                <input type="text" name="LIEU_NAISSANCE_AR" required>
            </div>
            <div class="input-box">
                <span class="details">Date de l'obtention de diplome</span>
                <input type="date" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}" name="DATE_OBTENTION" required>
            </div>
            <div class="input-box">
                <span class="details">filiere</span>
                <input type="text" required name="FILIERE">
            </div>
            <div class="input-box">
                <span class="details">filiere en arabe</span>
                <input type="text" required name="FILIERE_AR">
            </div>
            <div class="input-box">
                <span class="details">sexe</span>
                <input type="text" required name="SEXE">
            </div>

            <button type="submit" name="enregistrer" class="btn">Enregistrer</button>
        </div>
    </form>
</div>
<div id="divnav">
    <nav>
        <ul>
            <li><a href="index.php">acceuil</a></li>
            <li><a href="ajouter_etudiant.php">Ajouter_Etudiant</a></li>
            <li><a href="ajouter_utilisateur.php">Ajouter_utilisateur</a></li>
            <li><a href="reclamation.php">Réclamation</a></li>
            <li><a href="insertionProf.php">Insertion professionelle</a></li>
            <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
        </ul>
    </nav>
</div>
<div id="menubtn">
    <img src="../assets/image/menub.png" id="menu">
</div>

<script>
    var menubtn = document.getElementById("menubtn")
    var divnav = document.getElementById("divnav")
    var menu = document.getElementById("menu")

    menubtn.onclick = function () {
        if (divnav.style.right == "-250px") {
            divnav.style.right = "0";
            menu.src = "../assets/image/closeb.png"
        } else {
            divnav.style.right = "-250px";
            menu.src = "../assets/image/menub.png"
        }
    }
</script>
</body>
</html>