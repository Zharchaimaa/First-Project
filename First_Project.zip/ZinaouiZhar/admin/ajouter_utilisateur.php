<?php

// désactiver l'affichage des erreurs
error_reporting(0);

session_start();

require '../includes/constants.php';
require '../includes/logout.php';

// message d'infos
$message = '';

if (isset($_POST['enregistrer'])) {

    // connexion à la base de données
    require '../includes/connect.php';

    // récupérer formulaire
    $cne = $_POST['CNE'];
    $username = $_POST['username'];
    // hashe le password SHA1
    $password = sha1($_POST['password']);
    $profil = $_POST['profil'];

    // ajouter utilisateur
    $insert = "INSERT INTO UTILISATEUR (CNE,USERNAME,PASSWORD,PROFIL) VALUES ('$cne','$username','$password','$profil')";
    $result = mysqli_query($connexion, $insert);

    if ($result) {
        $message = 'Utilisateur est ajouté avec succés  !';
    } else {
        $message = 'Utilisateur non ajouter veuillez ressayer';
    }

    // fermer la connexion
    mysqli_close($connexion);
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/ajoutUtilisateur.css">
</head>
<body>
<?php if ($_SESSION['profil'] == PROFIL_ADMIN): ?>

<div class="container">
    <div class="title">Ajouter un utilisateur</div>
    <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>">
        <?php if (!empty($message)): ?>
            <div class="alert alert-success" role="alert">
                <?= $message ?>
            </div>
        <?php endif ?>
        <div class="user-details">
            <div class="input-box">
                <span class="details">CNE</span>
                <input type="text" name="CNE">
            </div>
            <div class="input-box">
                <span class="details">login</span>
                <input type="text" name="username" required>
            </div>
            <div class="input-box">
                <span class="details">password</span>
                <input type="text" name="password" required>
            </div>
            <div class="input-box">
                <span class="details">Profil</span>
                <input type="text" name="profil" required>
            </div>
            <button type="submit" name="enregistrer" class="btn">Enregistrer</button>
        </div>
    </form>
</div>


<div id="divnav">
    <nav>
        <ul>
            <li><a href="index.php">acceuil</a></li>
            <li><a href="ajouter_etudiant.php">Ajouter_Etudiant</a></li>
            <li><a href="ajouter_utilisateur.php">Ajouter_utilisateur</a></li>
            <li><a href="reclamation.php">Réclamation</a></li>
            <li><a href="insertionProf.php">Insertion professionelle</a></li>
            <li><a href="<?= $_SERVER['PHP_SELF'] ?>?logout">Déconnexion</a></li>
        </ul>
    </nav>
</div>
<div id="menubtn">
    <img src="../assets/image/menub.png" id="menu">
</div>

<script>
    var menubtn = document.getElementById("menubtn")
    var divnav = document.getElementById("divnav")
    var menu = document.getElementById("menu")

    menubtn.onclick = function () {
        if (divnav.style.right == "-250px") {
            divnav.style.right = "0";
            menu.src = "../assets/image/closeb.png"
        } else {
            divnav.style.right = "-250px";
            menu.src = "../assets/image/menub.png"
        }
    }
</script>

</body>

<?php endif; ?>
</html>
