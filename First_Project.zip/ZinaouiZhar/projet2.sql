-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 13 jan. 2022 à 08:12
-- Version du serveur : 5.7.36
-- Version de PHP : 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet2`
--

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `CNE` varchar(20) NOT NULL,
  `NOM` varchar(30) NOT NULL,
  `NOM_AR` varchar(30) NOT NULL,
  `PRENOM` varchar(30) NOT NULL,
  `PRENOM_AR` varchar(30) NOT NULL,
  `DATE_NAISSANCE` date NOT NULL,
  `LIEU_NAISSANCE` varchar(30) NOT NULL,
  `LIEU_NAISSANCE_AR` varchar(30) NOT NULL,
  `DATE_OBTENTION` date NOT NULL,
  `FILIERE` varchar(40) NOT NULL,
  `FILIERE_AR` varchar(50) NOT NULL,
  `SEXE` varchar(15) NOT NULL,
  `CONFIRMATION` int(11) NOT NULL,
  PRIMARY KEY (`CNE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`CNE`, `NOM`, `NOM_AR`, `PRENOM`, `PRENOM_AR`, `DATE_NAISSANCE`, `LIEU_NAISSANCE`, `LIEU_NAISSANCE_AR`, `DATE_OBTENTION`, `FILIERE`, `FILIERE_AR`, `SEXE`, `CONFIRMATION`) VALUES
('bb123', 'zinaoui', '??????', 'basma', '????', '2000-03-23', 'casablanca', '????? ???????', '2023-08-15', 'genie informatique', '????? ???????', 'feminin', 0),
('aa123', 'oiui', '??????', 'oumeima', '?????', '2000-03-23', 'casablanca', '????? ???????', '2023-08-15', 'genie informatique', '????? ???????', 'fï¿½minin', 1);

-- --------------------------------------------------------

--
-- Structure de la table `information_professionnelle`
--

DROP TABLE IF EXISTS `information_professionnelle`;
CREATE TABLE IF NOT EXISTS `information_professionnelle` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CNE` varchar(25) NOT NULL,
  `TRAVAIL` varchar(20) NOT NULL,
  `VILLE_PAYS` varchar(30) NOT NULL,
  `SECTEUR` varchar(50) NOT NULL,
  `ORGANISME` varchar(50) NOT NULL,
  `TEMPS_POUR_TRAVAIL` varchar(50) NOT NULL,
  `MOYEN_TRAVAIL` varchar(50) NOT NULL,
  `INSCRIRE_DOC` varchar(20) NOT NULL,
  `VILLE_PAYS_DOC` varchar(30) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CNE` (`CNE`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `information_professionnelle`
--

INSERT INTO `information_professionnelle` (`ID`, `CNE`, `TRAVAIL`, `VILLE_PAYS`, `SECTEUR`, `ORGANISME`, `TEMPS_POUR_TRAVAIL`, `MOYEN_TRAVAIL`, `INSCRIRE_DOC`, `VILLE_PAYS_DOC`) VALUES
(17, 'bb123', 'oui', 'casablanca', 'dev', 'it', '2 mois', 'linkdIn', 'oui', 'ENSAM'),
(18, 'aa123', 'oui', 'aaaa', 'aaa', 'aaa', 'aaa', 'aaa', 'non', '');

-- --------------------------------------------------------

--
-- Structure de la table `reclamation`
--

DROP TABLE IF EXISTS `reclamation`;
CREATE TABLE IF NOT EXISTS `reclamation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CNE` varchar(25) NOT NULL,
  `RECLAMATION` text NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CNE` (`CNE`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reclamation`
--

INSERT INTO `reclamation` (`ID`, `CNE`, `RECLAMATION`, `EMAIL`) VALUES
(15, 'aa123', 'prenom', 'oumeima.zinaoui57@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CNE` varchar(20) NOT NULL,
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `PROFIL` varchar(20) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `CNE_et` (`CNE`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`ID`, `CNE`, `USERNAME`, `PASSWORD`, `PROFIL`) VALUES
(1, 'aa123', 'admin', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'admin'),
(13, 'bb123', 'etudiant', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'etudiant'),
(14, 'aa123', 'oumeima', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'etudiant'),
(15, 'zz123', 'chaimaa', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'etudiant');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
